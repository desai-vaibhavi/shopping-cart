var Product = require('../models/product');

var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/shopping',{useNewUrlParser: true,useUnifiedTopology:true});

var products = [
    new Product({
        imagePath: 'https://cdn.impactinit.com/cdn/x/x@7d1439aa46/smss53/smsimg27/pv/ingram/02e72056.jpg',
        title: 'Nature Image',
        description: 'Awesome!!',
        price: 10
    }),
    new Product({
        imagePath: 'https://i.pinimg.com/474x/2d/ec/a7/2deca7d9ac8429a7fe96e21c7ab5c8b2.jpg',
        title: 'Nature Image1',
        description: 'Awesome!!',
        price: 20
    }),
    new Product({
        imagePath: 'https://sustainable.golf/assets/0004/0233/HHIA_Image1HarbourTownGolfLinksSeaPines_article_detail.jpg',
        title: 'Nature Image2',
        description: 'Awesome!!',
        price: 30
    }),
    new Product({
        imagePath: 'https://i.pinimg.com/474x/9b/bc/dc/9bbcdccdd1c0d10ebf7594bd29341dec.jpg',
        title: 'Nature Image3',
        description: 'Awesome!!',
        price: 40
    }),
    new Product({
        imagePath: 'https://img2.fonwall.ru/o/xq/la-jolla-waterfall-san-diego-kaliforniya.jpg?route=thumb&h=350',
        title: 'Nature Image4',
        description: 'Awesome!!',
        price: 50
    }),
    new Product({
        imagePath: 'https://iotzovik.ru/wp-content/uploads/2018/01/binokl-345x350.jpg',
        title: 'Nature Image5',
        description: 'Awesome!!',
        price: 60
    })
];

var done = 0;
for(var i=0; i<products.length; i++)
{
    products[i].save(function(err, result){
        done++;
        if(done === products.length)
        {
            exit();
        }
    });
}

function exit(){
    mongoose.disconnect();
}